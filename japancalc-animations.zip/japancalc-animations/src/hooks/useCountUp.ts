'use client';

import { useEffect, useRef, useState } from 'react';
import { useInView } from './useInView';

interface UseCountUpOptions {
  end: number;
  duration?: number;
  suffix?: string;
  prefix?: string;
}

export function useCountUp({
  end,
  duration = 1400,
  suffix = '',
  prefix = '',
}: UseCountUpOptions) {
  const { ref, isInView } = useInView<HTMLElement>({ threshold: 0.3 });
  const [count, setCount] = useState(0);
  const hasStarted = useRef(false);

  useEffect(() => {
    if (!isInView || hasStarted.current) return;
    hasStarted.current = true;

    const startTime = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // easeOutQuart — starts fast, eases gently to final value
      const eased = 1 - Math.pow(1 - progress, 4);
      setCount(Math.round(eased * end));
      if (progress < 1) requestAnimationFrame(step);
    };

    requestAnimationFrame(step);
  }, [isInView, end, duration]);

  return { ref, display: `${prefix}${count}${suffix}` };
}
