/**
 * 使い方サンプル — 既存のLPページに貼り付けるだけでOK
 * src/app/page.tsx （または該当のページコンポーネント）に統合してください
 */

import { CTAButton }  from '@/components/ui/CTAButton';
import { FadeUp }     from '@/components/ui/FadeUp';
import { useCountUp } from '@/hooks/useCountUp';

// ============================================================
// 1. CTAボタン — シマー + パルスリング + スパークル
// ============================================================
//
// 既存の <a> や <button> を <CTAButton> に差し替えるだけ。
//
// Before:
//   <a href="/buy" className="btn-primary">Get JapanCalc — $2.99</a>
//
// After:
//   <CTAButton href="/buy">Get JapanCalc — $2.99</CTAButton>
//
// サイズ指定:
//   <CTAButton href="/buy" size="md">Buy now</CTAButton>  // 小さめ
//   <CTAButton href="/buy" size="lg">Buy now</CTAButton>  // デフォルト（大）
//
// ============================================================


// ============================================================
// 2. FadeUp — スクロールで下からフェードイン
// ============================================================
//
// 任意の要素を <FadeUp> で囲むだけ。
//
// Before:
//   <section>
//     <h2>Features</h2>
//     <p>...</p>
//   </section>
//
// After:
//   <section>
//     <FadeUp><h2>Features</h2></FadeUp>
//     <FadeUp delay={100}><p>...</p></FadeUp>
//   </section>
//
// stagger（時間差）はdelayで指定（ms）:
//   <FadeUp delay={0}>   カード1 </FadeUp>
//   <FadeUp delay={120}> カード2 </FadeUp>
//   <FadeUp delay={240}> カード3 </FadeUp>
//
// ============================================================


// ============================================================
// 3. useCountUp — 数字のカウントアップ
// ============================================================
//
// 'use client' が必要なコンポーネント内で使う。
//
// 使用例（コンポーネント内）:

function StatsSection() {
  const currencies = useCountUp({ end: 150, suffix: '+' });
  const taxCats    = useCountUp({ end: 3,   suffix: '' });

  return (
    <div style={{ display: 'flex', gap: '48px' }}>

      {/* ref を span に付けるだけ — 画面に入ったらカウント開始 */}
      <div>
        <span
          ref={currencies.ref as React.RefObject<HTMLSpanElement>}
          style={{ fontSize: '48px', fontWeight: 700, color: '#EA7822' }}
        >
          {currencies.display}
        </span>
        <p>currencies supported</p>
      </div>

      <div>
        <span
          ref={taxCats.ref as React.RefObject<HTMLSpanElement>}
          style={{ fontSize: '48px', fontWeight: 700, color: '#EA7822' }}
        >
          {taxCats.display}
        </span>
        <p>tax categories</p>
      </div>

      {/* 固定値はそのまま書く */}
      <div>
        <span style={{ fontSize: '48px', fontWeight: 700, color: '#EA7822' }}>
          $2.99
        </span>
        <p>one-time, forever</p>
      </div>

    </div>
  );
}

// ============================================================
// 4. フィーチャーカードのホバーエフェクト
// ============================================================
//
// globals.css に以下を追加するだけ（CSSのみで完結）:
//
//  .feature-card {
//    transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1),
//                border-color 0.25s ease;
//  }
//  .feature-card:hover {
//    transform: translateY(-8px);
//    border-color: #EA7822;
//  }
//
// ============================================================

export { StatsSection };
