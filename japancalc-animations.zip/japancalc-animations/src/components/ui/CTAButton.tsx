'use client';

import Link from 'next/link';
import styles from './CTAButton.module.css';

interface CTAButtonProps {
  children: React.ReactNode;
  href?: string;
  onClick?: () => void;
  className?: string;
  size?: 'md' | 'lg';
}

export function CTAButton({
  children,
  href,
  onClick,
  className = '',
  size = 'lg',
}: CTAButtonProps) {
  const sparkles = (
    <>
      <span className={styles.sparkle1} aria-hidden="true" />
      <span className={styles.sparkle2} aria-hidden="true" />
      <span className={styles.sparkle3} aria-hidden="true" />
    </>
  );

  const cls = `${styles.btn} ${styles[size]} ${className}`;

  if (href) {
    return (
      <Link href={href} className={cls}>
        {sparkles}
        {children}
      </Link>
    );
  }

  return (
    <button type="button" onClick={onClick} className={cls}>
      {sparkles}
      {children}
    </button>
  );
}
