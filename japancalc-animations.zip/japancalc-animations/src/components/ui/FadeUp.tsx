'use client';

import { useInView } from '@/hooks/useInView';
import styles from './FadeUp.module.css';

interface FadeUpProps {
  children: React.ReactNode;
  delay?: number;        // ms単位の遅延（stagger用）
  className?: string;
  as?: keyof JSX.IntrinsicElements;
}

export function FadeUp({
  children,
  delay = 0,
  className = '',
  as: Tag = 'div',
}: FadeUpProps) {
  const { ref, isInView } = useInView<HTMLElement>();

  return (
    <Tag
      ref={ref as React.RefObject<HTMLElement>}
      className={`${styles.wrapper} ${isInView ? styles.visible : ''} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}
